
Initial SetUp (do the following one time)
1. Open a terminal in this directory.
2. Type "chmod +x Configure"
3. Type "sudo ./Configure"
4. Type "chmod +x LaunchMe"

-----

To run the BirdBrain Robot Server type "./LaunchMe"

