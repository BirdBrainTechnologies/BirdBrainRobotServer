readme - Snap! 4.0
------------------

this document is just a stub as of now. For the first official release of Snap! 4.0 it will contain release notes covering the following issues:

saving, loading, exporting, importing

artefacts: projects, blocks, sprites

URL options: #run: #open: #lang: #signup

dynamic content (currently deactivated):
	http://snap.berkeley.edu/cloudmsg.txt
	http://snap.berkeley.edu/motd.txt

supported browsers, problems with the Android virtual keyboard

supported browser / OS settings

SVG support limitations

OS/X: turn LCD font smoothing off

Beware of third-party Chrome toolbars and iFrames
