If in Linux, do sudo ./Configure once (you may need to chmod +x Configure first to make it executable)

Then do ./LaunchSnap

